<?php
// session_start();
include("../template/fac-auth.php");
include("../template/sidebar-fac.php");
?>





                <?php
                $con = mysqli_connect("localhost", "root", "", "erp_alvas");
                if (mysqli_connect_error()) {
                    echo "error";
                } else {
                    $faculty_name = $_SESSION["username"];
                   
                    $que = "select * from faculty_details where faculty_name=\"$faculty_name\"";

                    $result = $con->query($que);
                    foreach ($result as $row) {
                ?>

                        <div class="card" style="padding:3%; box-shadow: 1px 5px 18px black; border:1px solid red">
                            <div class="row">

                                <div class="col-lg-3 col-6 " style="margin-left: 2%;">

                                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSkkBpQ9U04geL7EKfAaXSxUCshUNLfDTKzlQ&usqp=CAU" alt="" srcset="" width="80%" height="80%">

                                </div>
                                <div class="col-lg-8 col-6" style="text-align: center;">
                                    <div class="row">
                                        <h2>
                                            <span>
                                                <?php echo $row["faculty_name"] ?>
                                            </span>
                                        </h2>
                                    </div>
                                    <div class="row">

                                        <span>

                                        </span>

                                    </div>
                                    <div class="row">
                                        <span class="value"><?php echo $row["faculty_email"] ?></span>
                                    </div>
                                    <div class="row">
                                        <span class="value"><?php echo $row["faculty_contact"] ?></span>
                                    </div>
                                </div>

                            </div>
                        </div>



                        <div class="card mt-2" style="padding:3%; box-shadow: 1px 5px 18px black; border:1px solid red">

                            <div class="row">

                                <p style="font-style: italic;font-weight:600; font-size:larger;color:black;">Basic Details</p>

                                <div class="col col-lg-4 col-12 label mt-2">
                                    Faculty Id : <span class="value"><?php echo $row["faculty_id"] ?></span>
                                </div>

                                <div class="col col-lg-4 col-12 label mt-2">
                                    Designation : <span class="value"><?php echo $row["faculty_desg"] ?></span>
                                </div>

                                <div class="col col-lg-4 col-12 label mt-2">
                                    Department : <span class="value"><?php echo $row["faculty_dept"] ?></span>
                                </div>

                                <div class="col col-lg-4 col-12 label mt-2">
                                    Year Of Joining : <span class="value"><?php echo $row["faculty_yoj"] ?></span>
                                </div>

                                <div class="col col-lg-4 col-12 label mt-2">
                                    Date Of Birth : <span class="value"><?php echo $row["faculty_dob"] ?></span>
                                </div>

                                <div class="col col-lg-4 col-12 label mt-2">
                                    Parmanent Address : <span class="value"><?php echo $row["faculty_parmenent_address"] ?></span>
                                </div>


                                <div class="col col-lg-4 col-12 label mt-2">
                                    Correspondence Address : <span class="value"><?php echo $row["faculty_present_address"] ?></span>
                                </div>


                                <div class="col col-lg-4 col-12 label mt-2">
                                    Teaching Experience : <span class="value"><?php echo $row["faculty_teaching_exp"] ?></span>
                                </div>

                                <div class="col col-lg-4 col-12 label mt-2">
                                    Industry Experience : <span class="value"><?php echo $row["faculty_industry_exp"] ?></span>
                                </div>

                                <div class="col col-lg-4 col-12 label mt-2">
                                    AICTE ID : <span class="value"><?php echo $row["faculty_aicte_id"] ?></span>
                                </div>

                            </div>



                            <div class="row mt-4">
                                <p style="font-style: italic;font-weight:600;color:black;">Education Details</p>
                                <h5> <em>UG</em> </h5>
                                <div class="col col-lg-4 col-12 label ">
                                    BE DEPT : <span class="value"><?php echo $row["faculty_ug_dept"] ?></span>


                                </div>
                                <div class="col col-lg-4 col-12 label ">

                                    Year of Passing : <span class="value"><?php echo $row["faculty_ug_year"] ?></span>


                                </div>
                                <div class="col col-lg-4 col-12 label ">

                                    College name: <span class="value"><?php echo $row["faculty_ug_college"] ?></span>
                                </div>
                                <br>

                                <h5> <em> PG</em> </h5>

                                <div class="col col-lg-4 col-12 label ">
                                    M Tech,DEPARTMENT : <span class="value"><?php echo $row["faculty_pg_dept"] ?></span>
                                </div>

                                <div class="col col-lg-4 col-12 label mt-2 ">

                                    Year of Passing: <span class="value"><?php echo $row["faculty_pg_year"] ?></span>


                                </div>
                                <div class="col col-lg-4 col-12 label mt-2 ">
                                    College name: <span class="value"><?php echo $row["faculty_pg_college"] ?></span>
                                </div>

                                <h5> <em> PHD</em> </h5>
                                <div class="col col-lg-4 col-12 label mt-2 ">
                                    Registration date : <span class="value"><?php echo $row["faculty_phd_reg"] ?></span>
                                </div>

                                <div class="col col-lg-4 col-12 label mt-2 ">
                                    Current Status : <span class="value"><?php echo $row["faculty_phd_status"] ?></span>
                                </div>

                                <div class="col col-lg-4 col-12 label mt-2 ">
                                    Guide Name : <span class="value"><?php echo $row["faculty_phd_guide"] ?></span>
                                </div>

                                <div class="col col-lg-4 col-12 label mt-2 ">
                                    Topic of research : <span class="value"><?php echo $row["faculty_phd_topic"] ?></span>
                                </div>

                                <div class="col col-lg-4 col-12 label mt-2 ">

                                    Research Domain : <span class="value"><?php echo $row["faculty_phd_domain"] ?></span>
                                </div>

                                <div class="col col-lg-4 col-12 label mt-2 ">
                                    University/research center : <span class="value"><?php echo $row["faculty_phd_center"] ?></span>
                                </div>

                                <div class="col col-lg-4 col-12 label mt-2 ">
                                    Year of joining : <span class="value"><?php echo $row["faculty_phd_yoj"] ?></span>
                                </div>

                                <div class="col col-lg-4 col-12 label mt-2 ">
                                    Year of completion : <span class="value"><?php echo $row["faculty_phd_complition"] ?></span>
                                </div>

                                <div class="col col-lg-4 col-12 label mt-2 ">
                                    Teaching Subjects : <span class="value"><?php echo $row["faculty_sub_handel"] ?></span>
                                </div>


                            </div>
                            <form action="faculty_view_edit.php" method="post">
                                <button type="submit" class="btn" style="float: right;"><i class="fas fa-edit"></i></button>
                            </form>
                        </div>


                <?php
                    }
                } ?>



                <?php
                $con = mysqli_connect("localhost", "root", "", "erp_alvas");
                if (mysqli_connect_error()) {
                    echo "error";
                } else {
                    $faculty_id = $_SESSION["username"];
                    $que = "select * from faculty_workshop_details where faculty_id=\"$faculty_id\"";
                    $result = $con->query($que);

                    // foreach ($result as $row) {
                    //     $admission_no = $row["adm_no"];
                    //     $_SESSION["adm_no"] = $row["adm_no"];
                    //     $que = "select * from sslc_details where adm_no=\"$admission_no\"";
                    //     $re = $con->query($que);
                ?>
                    <div class="card mt-3" style="padding:3%; box-shadow: 1px 5px 18px black; border:1px solid red">
                        <p style="font-style: italic;font-weight:600;color:black;">Workshop Details</p>

                        <?php foreach ($result as $r) {
                        ?>


                            <div class="row">

                                <form action="faculty_workshop_edit.php" method="post">
                                    <input type="text" name="id" id="" value="<?php echo $r["id"] ?>" hidden>
                                    <input type="text" name="work_name" id="" value="<?php echo $r["faculty_workshop_name"] ?>" hidden>
                                    <input type="text" name="work_title" id="" value="<?php echo $r["faculty_workshop_title"] ?>" hidden>
                                    <input type="text" name="work_days" id="" value="<?php echo $r["faculty_workshop_no_of_days"] ?>" hidden>

                                    <div class="row">
                                        <div class="col col-lg-4 col-12 label mt-2">
                                            Workshop Name : <span class="value"><?php echo $r["faculty_workshop_name"] ?></span>
                                        </div>

                                        <div class="col col-lg-4 col-12 label mt-2">
                                            Workshop Title : <span class="value"><?php echo $r["faculty_workshop_title"] ?></span>


                                        </div>


                                        <div class="col col-lg-4 col-12 label mt-2">
                                            No of Days Conducted : <span class="value"><?php echo $r["faculty_workshop_no_of_days"] ?></span>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn" style="float: right;"><i class="fas fa-edit"></i></button>
                                </form>
                            </div>


                    <?php

                        }
                    } ?>
                    </div>



                    <?php
                    $con = mysqli_connect("localhost", "root", "", "erp_alvas");
                    if (mysqli_connect_error()) {
                        echo "error";
                    } else {
                        $faculty_id = $_SESSION["username"];
                        $que = "select * from faculty_ppr_details where faculty_id=\"$faculty_id\"";
                        $result = $con->query($que);

                        // foreach ($result as $row) {
                        //     $_SESSION["admission_no"] = $row["adm_no"];
                        //     $que = "select * from puc_details where adm_no=\"$admission_no\"";
                        //     $re = $con->query($que);
                    ?><div class="card mt-3" style="padding:3%; box-shadow: 1px 5px 18px black;border:1px solid red">
                            <div class="row">
                                <p style="font-style: italic;font-weight:600;color:black;">Published Paper Details </p>
                                <?php
                                foreach ($result as $r) {
                                ?>


                                    <form action="faculty_paper_edit.php" method="post">

                                        <input type="text" name="id" id="" value="<?php echo $r["id"] ?>" hidden>
                                        <input type="text" name="faculty_ppr_type" id="" value="<?php echo $r["faculty_ppr_type"] ?>" hidden>
                                        <input type="text" name="faculty_ppr_year" id="" value="<?php echo $r["faculty_ppr_year"] ?>" hidden>
                                        <input type="text" name="faculty_ppr_title" id="" value="<?php echo $r["faculty_ppr_title"] ?>" hidden>
                                        <input type="text" name="faculty_ppr_jourrnal" id="" value="<?php echo $r["faculty_ppr_jourrnal"] ?>" hidden>
                                        <input type="text" name="faculty_ppr_pub_date" id="" value="<?php echo $r["faculty_ppr_pub_date"] ?>" hidden>
                                        <input type="text" name="faculty_ppr_volume" id="" value="<?php echo $r["faculty_ppr_volume"] ?>" hidden>
                                        <input type="text" name="faculty_ppr_issue" id="" value="<?php echo $r["faculty_ppr_issue"] ?>" hidden>
                                        <input type="text" name="faculty_ppr_issn" id="" value="<?php echo $r["faculty_ppr_issn"] ?>" hidden>

                                        <div class="row">
                                            <div class="col col-lg-4 col-12 label mt-2">
                                                Paper Type : <span class="value"><?php echo $r["faculty_ppr_type"] ?></span>


                                            </div>
                                            <div class="col col-lg-4 col-12 label mt-2">
                                                Academic Year : <span class="value"><?php echo $r["faculty_ppr_year"] ?></span>


                                            </div>


                                            <div class="col col-lg-4 col-12 label mt-2">
                                                Title of the Paper : <span class="value"><?php echo $r["faculty_ppr_title"] ?></span>


                                            </div>
                                            <div class="col col-lg-4 col-12 label mt-2">
                                                Name of the Journal/Conference :<span class="value"><?php echo $r["faculty_ppr_jourrnal"] ?></span>


                                            </div>
                                            <div class="col col-lg-4 col-12 label mt-2">

                                                Date of Publication : <span class="value"><?php echo $r["faculty_ppr_pub_date"] ?></span>


                                            </div>
                                            <div class="col col-lg-4 col-12 label mt-2">
                                                Volume : <span class="value"><?php echo $r["faculty_ppr_volume"] ?></span>


                                            </div>
                                            <div class="col col-lg-4 col-12 label mt-2">
                                                Issue : <span class="value"><?php echo $r["faculty_ppr_issue"] ?></span>


                                            </div>

                                            <div class="col col-lg-4 col-12 label mt-2">
                                                ISSN no : <span class="value"><?php echo $r["faculty_ppr_issn"] ?></span>


                                            </div>
                                        </div>
                                        <button type="submit" class="btn" style="float: right;"><i class="fas fa-edit"></i></button>
                                    </form>
                            </div>



                    <?php

                                }
                            } ?>
                        </div>
            </div>
        </div>
        <!-- page content end -->
    </div>
    </div>
    <script src="../asset/style/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js" integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            $('#sidebarCollapse').on('click', function() {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
</body>

</html>